# Polytech Quest: Python + Physics (Year 1, Mid-1)
Android WebView app, same structure as SnakeByte. UI is `app/src/main/assets/index.html`.
- Learn path: lessons (read, formulas, 🔊 read aloud) then a quiz (MCQ, true/false, typed numbers), 3 lives, XP, daily goal, streak.
- Physics: 9 SBTET units (from SnakeByte). Python: 4 units, 7 lessons. Add more by editing the `PY` array (Python) or `U` array (Physics).
- Fully offline. Progress is stored on the device (`polytech_quest_v1`).

## Make the APK
1. Create a GitHub repo and upload everything in this folder (keep `.github`).
2. Actions tab > "Build PolytechQuest APK" > Run workflow (it also runs on every push to main).
3. Download `PolytechQuest-v1-debug.apk` from Releases and install it on your phone.
