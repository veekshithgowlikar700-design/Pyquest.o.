# Polytech Quest does not require custom ProGuard rules.
